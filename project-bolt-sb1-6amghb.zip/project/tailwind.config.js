/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        serif: ['Merriweather', 'serif'],
        mono: ['Space Mono', 'monospace'],
      },
      colors: {
        navy: {
          900: '#0A0B1E',
          800: '#12142B',
          700: '#1A1D3C',
        },
        accent: {
          pink: '#FF3DC7',
          purple: '#8B5CF6',
          blue: '#3B82F6',
          neon: '#00F5FF',
          indigo: '#4F46E5',
        },
        light: {
          bg: '#F8FAFC',
          surface: '#FFFFFF',
          card: '#F1F5F9',
          border: '#E2E8F0',
          text: '#1E293B',
          muted: '#64748B',
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'glass-light': 'linear-gradient(to right bottom, rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.7))',
      },
    },
  },
  plugins: [],
};