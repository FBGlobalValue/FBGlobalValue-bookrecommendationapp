import { BookRecommendation } from './openai';
import CryptoJS from 'crypto-js';

interface AmazonProduct {
  url: string;
  price?: string;
}

export async function getAmazonLink(book: BookRecommendation): Promise<AmazonProduct> {
  const associateTag = import.meta.env.VITE_AMAZON_ASSOCIATE_TAG;
  
  // If no associate tag is present, return a direct Amazon search link
  if (!associateTag) {
    const searchQuery = encodeURIComponent(`${book.title} ${book.author}`);
    return {
      url: `https://www.amazon.com/s?k=${searchQuery}`,
    };
  }

  // Create affiliate search link with associate tag
  const searchQuery = encodeURIComponent(`${book.title} ${book.author}`);
  return {
    url: `https://www.amazon.com/s?k=${searchQuery}&tag=${associateTag}`,
  };
}