import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

interface Inspiration {
  type: string;
  value: string;
}

export interface BookRecommendation {
  title: string;
  author: string;
  probabilityScore: number;
  connections: string[];
  whyYoullLoveIt: string;
}

export interface RecommendationError {
  message: string;
  code: string;
}

export async function getBookRecommendations(
  inspirations: Array<Inspiration>
): Promise<BookRecommendation[] | RecommendationError> {
  if (!import.meta.env.VITE_OPENAI_API_KEY) {
    return {
      message: "OpenAI API key is missing. Please check your environment variables.",
      code: "MISSING_API_KEY"
    };
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo-16k",
      messages: [
        {
          role: "system",
          content: `You are an AI book recommendation assistant. Your task is to provide EXACTLY 10 book recommendations following these criteria:

1. WEIGHTING SYSTEM (Must be strictly followed):
- 40% - Similar books (plot, style, themes, pacing)
- 30% - Author style (similar authors)
- 15% - Genre match
- 10% - Theme alignment
- 5% - Mood/tone match

2. DIVERSITY REQUIREMENTS (Mandatory):
- Maximum of 2 books per author
- Include books from different time periods and styles
- Mix of classic and contemporary works
- Include both well-known and hidden gems
- Vary writing styles and perspectives

3. SCORING RULES:
- Probability scores must reflect the weighting system
- Scores should range from 65-95% (no perfect 100%)
- Higher scores for stronger matches

4. RESPONSE FORMAT (CRITICAL - Must follow exactly):

Book Title: [Title]
Book Author: [Author]
Probability Score: [XX]
Connections to Your Preferences:
• Similar books: [Description]
• Author style: [Description]
• Genre match: [Description]
Why You'll Love This Book:
[2-3 compelling sentences]

---

IMPORTANT: 
- Always start each recommendation with "Book Title:"
- Use bullet points with "•" (not "-" or "*")
- Include exactly 3 connection points for each book
- Maintain consistent formatting throughout all 10 recommendations
- Add "---" between each recommendation
- Ensure each section is properly labeled and formatted`
        },
        {
          role: "user",
          content: generatePrompt(inspirations)
        }
      ],
      temperature: 0.7,
      max_tokens: 4000,
      presence_penalty: 0.6,
      frequency_penalty: 0.8
    });

    const content = response.choices[0].message.content;
    if (!content) {
      return {
        message: "No recommendations were generated. Please try again.",
        code: "NO_CONTENT"
      };
    }

    const recommendations = parseRecommendations(content);
    
    if (recommendations.length === 0) {
      return {
        message: "Failed to parse recommendations. Please try again.",
        code: "PARSE_ERROR"
      };
    }

    if (recommendations.length < 10) {
      return {
        message: "Incomplete recommendations received. Please try again.",
        code: "INCOMPLETE_RESULTS"
      };
    }

    // Verify author diversity (maximum 2 books per author)
    const authorCounts = new Map<string, number>();
    for (const rec of recommendations) {
      const authorKey = rec.author.toLowerCase().trim();
      authorCounts.set(authorKey, (authorCounts.get(authorKey) || 0) + 1);
      
      if (authorCounts.get(authorKey)! > 2) {
        return {
          message: "Received duplicate authors. Please try again.",
          code: "AUTHOR_LIMIT_EXCEEDED"
        };
      }
    }

    return recommendations;
  } catch (error) {
    console.error('Error getting recommendations:', error);
    return {
      message: "Failed to get book recommendations. Please try again.",
      code: "API_ERROR"
    };
  }
}

function parseRecommendations(content: string): BookRecommendation[] {
  const recommendations: BookRecommendation[] = [];
  const sections = content.split('---').filter(Boolean);

  for (const section of sections) {
    try {
      const titleMatch = section.match(/Book Title:\s*([^\n]+)/);
      const authorMatch = section.match(/Book Author:\s*([^\n]+)/);
      const scoreMatch = section.match(/Probability Score:\s*(\d+)/);
      const connectionsMatch = section.match(/Connections to Your Preferences:([\s\S]*?)Why You'll Love This Book:/);
      const whyLoveMatch = section.match(/Why You'll Love This Book:\s*([\s\S]*?)(?=(?:\n\s*(?:---|Book Title:|$)))/);

      if (!titleMatch || !authorMatch || !scoreMatch || !connectionsMatch || !whyLoveMatch) {
        continue;
      }

      const title = titleMatch[1].trim();
      const author = authorMatch[1].trim();
      const probabilityScore = parseInt(scoreMatch[1], 10);
      
      const connections = connectionsMatch[1]
        .split('\n')
        .map(line => line.trim())
        .filter(line => line.startsWith('•'))
        .map(line => line.substring(1).trim());

      const whyYoullLoveIt = whyLoveMatch[1].trim();

      if (
        title &&
        author &&
        probabilityScore >= 65 &&
        probabilityScore <= 95 &&
        connections.length === 3
      ) {
        recommendations.push({
          title,
          author,
          probabilityScore,
          connections,
          whyYoullLoveIt
        });
      }
    } catch (error) {
      continue;
    }
  }

  return recommendations;
}

function generatePrompt(inspirations: Array<Inspiration>): string {
  const grouped = inspirations.reduce((acc, curr) => {
    if (!acc[curr.type]) {
      acc[curr.type] = [];
    }
    acc[curr.type].push(curr.value);
    return acc;
  }, {} as Record<string, string[]>);

  return `Based on these user preferences:

${grouped['BOOK']?.length ? `BOOK(s): ${grouped['BOOK'].join(', ')}` : ''}
${grouped['AUTHOR']?.length ? `AUTHOR(s): ${grouped['AUTHOR'].join(', ')}` : ''}
${grouped['GENRE']?.length ? `GENRE(s): ${grouped['GENRE'].join(', ')}` : ''}
${grouped['THEME']?.length ? `THEME(s): ${grouped['THEME'].join(', ')}` : ''}
${grouped['MOOD']?.length ? `MOOD(s): ${grouped['MOOD'].join(', ')}` : ''}

Please provide EXACTLY 10 book recommendations following the specified format.

Remember:
- Use bullet points with "•" symbol
- Include exactly 3 connection points for each book
- Add "---" between recommendations
- Maximum 2 books per author
- Ensure probability scores reflect genuine match quality (65-95%)
- Format each recommendation exactly as shown in the system message`;
}