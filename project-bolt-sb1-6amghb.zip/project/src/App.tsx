import React from 'react';
import { Header } from './components/Header';
import { InspirationBoard } from './components/InspirationBoard';
import { ThemeProvider } from './context/ThemeContext';

function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-light-bg dark:bg-navy-900 transition-colors">
        <Header />
        <InspirationBoard />
      </div>
    </ThemeProvider>
  );
}

export default App;