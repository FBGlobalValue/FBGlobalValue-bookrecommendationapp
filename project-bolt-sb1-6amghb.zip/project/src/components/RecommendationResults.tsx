import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { BookRecommendation } from '../services/openai';
import { getAmazonLink } from '../services/amazon';
import { BookOpen, Sparkles, Star, ShoppingCart } from 'lucide-react';

interface RecommendationResultsProps {
  recommendations: string | null;
}

interface BookWithAmazon extends BookRecommendation {
  amazonLink?: string;
}

export function RecommendationResults({ recommendations }: RecommendationResultsProps) {
  const { theme } = useTheme();
  const [booksWithLinks, setBooksWithLinks] = React.useState<BookWithAmazon[]>([]);

  const parsedRecommendations = React.useMemo(() => {
    if (!recommendations) return [];
    try {
      return JSON.parse(recommendations) as BookRecommendation[];
    } catch {
      return [];
    }
  }, [recommendations]);

  React.useEffect(() => {
    async function fetchAmazonLinks() {
      const updatedBooks = await Promise.all(
        parsedRecommendations.map(async (book) => {
          try {
            const amazonProduct = await getAmazonLink(book);
            return {
              ...book,
              amazonLink: amazonProduct.url,
            };
          } catch (error) {
            console.error('Error fetching Amazon link:', error);
            return book;
          }
        })
      );
      setBooksWithLinks(updatedBooks);
    }

    if (parsedRecommendations.length > 0) {
      fetchAmazonLinks();
    }
  }, [parsedRecommendations]);

  if (!recommendations) return null;

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-mono text-center mb-12 bg-gradient-to-r from-accent-blue via-accent-purple to-accent-pink text-transparent bg-clip-text">
        Your Personalized Book Recommendations
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {booksWithLinks.map((book, index) => (
          <div
            key={index}
            className={`relative rounded-xl overflow-hidden ${
              theme === 'dark'
                ? 'bg-navy-800/90 border border-accent-purple/20'
                : 'bg-white border border-light-border'
            } shadow-lg hover:shadow-xl transition-all duration-300`}
          >
            <div className="absolute top-0 right-0 p-4">
              <div className="flex items-center gap-1 bg-accent-purple/90 text-white px-3 py-1 rounded-full text-sm font-mono">
                <Star size={14} className="fill-current" />
                <span>{book.probabilityScore}%</span>
              </div>
            </div>

            <div className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className={`p-3 rounded-lg ${
                    theme === 'dark' ? 'bg-navy-700' : 'bg-light-card'
                  }`}>
                    <BookOpen className="w-6 h-6 text-accent-purple" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1 bg-gradient-to-r from-accent-blue to-accent-pink text-transparent bg-clip-text">
                    {book.title}
                  </h3>
                  <p className={`text-sm font-mono ${
                    theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  }`}>
                    by {book.author}
                  </p>
                </div>
              </div>

              <div className="mt-6 space-y-4">
                <div>
                  <h4 className="flex items-center gap-2 text-sm font-mono mb-2 text-accent-purple">
                    <Sparkles size={16} />
                    Connections to Your Preferences
                  </h4>
                  <ul className="space-y-2">
                    {book.connections.map((connection, i) => (
                      <li
                        key={i}
                        className={`flex items-center gap-2 text-sm ${
                          theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-accent-purple/60" />
                        {connection}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-sm font-mono mb-2 text-accent-purple">
                    Why You'll Love This Book
                  </h4>
                  <p className={`text-sm ${
                    theme === 'dark' ? 'text-gray-300' : 'text-gray-700'
                  }`}>
                    {book.whyYoullLoveIt}
                  </p>
                </div>

                {book.amazonLink && (
                  <div className="pt-4">
                    <a
                      href={book.amazonLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-[#FF9900] hover:bg-[#FF9900]/90 text-white rounded-lg transition-colors"
                    >
                      <ShoppingCart size={18} />
                      Buy on Amazon
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}