import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { BookRecommendation, RecommendationError, getBookRecommendations } from '../services/openai';
import { RecommendationResults } from './RecommendationResults';
import { Sparkles } from 'lucide-react';

type InspirationType = 'BOOK' | 'AUTHOR' | 'GENRE' | 'THEME' | 'MOOD';

interface Inspiration {
  type: InspirationType;
  value: string;
}

export function InspirationBoard() {
  const { theme } = useTheme();
  const [selectedType, setSelectedType] = useState<InspirationType>('BOOK');
  const [inputValue, setInputValue] = useState('');
  const [inspirations, setInspirations] = useState<Inspiration[]>([]);
  const [recommendations, setRecommendations] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAdd = () => {
    if (!inputValue.trim()) return;
    
    setInspirations(prev => [...prev, { type: selectedType, value: inputValue.trim() }]);
    setInputValue('');
  };

  const handleRemove = (index: number) => {
    setInspirations(prev => prev.filter((_, i) => i !== index));
  };

  const handleGetRecommendations = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await getBookRecommendations(inspirations);
      
      if ('code' in result) {
        const error = result as RecommendationError;
        setError(error.message);
      } else {
        setRecommendations(JSON.stringify(result));
      }
    } catch (err) {
      setError('Failed to get recommendations. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-4xl font-mono text-center mb-12 bg-gradient-to-r from-accent-blue via-accent-purple to-accent-pink text-transparent bg-clip-text">
        Add Inspiration To Find Your Next Favorite Book...
      </h1>

      <div className="space-y-8">
        <div className="flex flex-wrap gap-4 justify-center">
          {(['BOOK', 'AUTHOR', 'GENRE', 'THEME', 'MOOD'] as InspirationType[]).map((type) => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-4 py-2 rounded-lg font-mono transition-all ${
                selectedType === type
                  ? 'bg-accent-purple text-white'
                  : theme === 'dark'
                  ? 'bg-navy-800 text-gray-300 hover:bg-navy-700'
                  : 'bg-light-card text-gray-700 hover:bg-gray-200'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        <div className="flex gap-4">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAdd()}
            placeholder={`Enter a ${selectedType.toLowerCase()}...`}
            className={`flex-1 px-4 py-3 rounded-lg font-mono border ${
              theme === 'dark'
                ? 'bg-navy-800 border-accent-purple/20 text-white'
                : 'bg-white border-light-border text-gray-900'
            } focus:outline-none focus:ring-2 focus:ring-accent-purple/50`}
          />
          <button
            onClick={handleAdd}
            className="px-6 py-2 rounded-lg bg-accent-purple hover:bg-accent-purple/90 text-white font-mono transition-colors"
          >
            Add
          </button>
        </div>

        <div className={`min-h-[200px] rounded-xl p-8 ${
          theme === 'dark'
            ? 'bg-navy-800/90 border border-accent-purple/20'
            : 'bg-white border border-light-border'
        }`}>
          <h2 className="text-2xl font-mono text-center mb-8 bg-gradient-to-r from-accent-blue to-accent-pink text-transparent bg-clip-text">
            Your Inspiration Board
          </h2>

          <div className="flex flex-wrap gap-4 mb-8">
            {inspirations.map((inspiration, index) => (
              <div
                key={index}
                className={`relative group px-4 py-2 rounded-lg ${
                  theme === 'dark' ? 'bg-navy-700' : 'bg-light-card'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-mono ${
                    theme === 'dark' ? 'text-accent-purple' : 'text-accent-blue'
                  }`}>
                    {inspiration.type}
                  </span>
                  <span className={theme === 'dark' ? 'text-white' : 'text-gray-900'}>
                    {inspiration.value}
                  </span>
                </div>
                <button
                  onClick={() => handleRemove(index)}
                  className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-red-500 text-white opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  ×
                </button>
              </div>
            ))}
          </div>

          {error && (
            <div className="mb-6 p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-500 text-sm">
              ⚠️ {error}
            </div>
          )}

          {inspirations.length >= 2 && (
            <div className="flex justify-center">
              <button
                onClick={handleGetRecommendations}
                disabled={isLoading}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-accent-blue to-accent-pink text-white font-mono hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                <Sparkles className="w-5 h-5" />
                {isLoading ? 'Finding Your Books...' : 'Get Your Recommendations'}
              </button>
            </div>
          )}
        </div>

        <div className="mt-4 text-center">
          <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            Please Note: BookRecommendationapp.com is a participant in the Amazon Services LLC Associates Program, which means we earn a commission from qualifying purchases made through links on this site. Thank you in advance for supporting this site and helping to keep it FREE!
          </p>
        </div>

        {recommendations && <RecommendationResults recommendations={recommendations} />}
      </div>
    </div>
  );
}