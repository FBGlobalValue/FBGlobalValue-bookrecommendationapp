import React from 'react';
import { BookOpenCheck, User } from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';

export function Header() {
  return (
    <header className="bg-light-surface dark:bg-navy-900 shadow-sm transition-colors border-b border-light-border dark:border-navy-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex items-center">
              <BookOpenCheck className="h-8 w-8 text-accent-blue" />
              <div className="ml-2">
                <span className="text-xl font-serif font-semibold bg-gradient-to-r from-accent-blue to-accent-pink text-transparent bg-clip-text">
                  bookrecommendationapp.com
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <button className="flex items-center text-light-text dark:text-gray-300 hover:text-accent-purple dark:hover:text-accent-pink">
              <User className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}